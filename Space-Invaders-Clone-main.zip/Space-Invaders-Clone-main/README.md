# A Clone of Space Invaders

Made for my IMGD 1001 course at WPI.

Made following this tutorial: https://github.com/WheatleyTheCore/Space-Invaders-Clone.


